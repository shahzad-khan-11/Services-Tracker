<?php
session_start();
include "db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}

$uid = $_SESSION['user_id'];

/* Total reports */
$total = $conn->query("SELECT COUNT(*) c FROM reports WHERE user_id=$uid")->fetch_assoc()['c'];

/* Completed reports */
$completed = $conn->query("SELECT COUNT(*) c FROM reports WHERE user_id=$uid AND status='Completed'")->fetch_assoc()['c'];

/* Fake reports */
$fake = $conn->query("SELECT COUNT(*) c FROM reports WHERE user_id=$uid AND is_valid=0")->fetch_assoc()['c'];

/* Avg rating */
$ratingRes = $conn->query("SELECT AVG(rating) avg FROM feedback WHERE user_id=$uid");
$avgRating = $ratingRes->fetch_assoc()['avg'];
if(!$avgRating) $avgRating = 0;

/* Final score */
$score = ($total * 10) + ($completed * 20) - ($fake * 30) + ($avgRating * 10);
$score = round($score);

/* Trust level */
if($score >= 200) $trust = "Highly Trusted";
else if($score >= 100) $trust = "Trusted User";
else if($score >= 50) $trust = "Normal";
else $trust = "Low Trust";
?>
<!DOCTYPE html>
<html>
<head>
<title>My Score | Service Tracker</title>
<link rel="stylesheet" href="css/main.css">
<style>
.score-box{
max-width:600px;
margin:80px auto;
background:#fff;
padding:40px;
border-radius:12px;
box-shadow:0 10px 30px rgba(0,0,0,.15);
text-align:center;
}
.score{
font-size:64px;
color:#2563eb;
font-weight:bold;
}
.trust{
margin-top:10px;
font-size:20px;
color:#16a34a;
font-weight:600;
}
.breakdown{
margin-top:25px;
text-align:left;
}
.breakdown p{
margin:8px 0;
font-size:16px;
}
</style>
</head>

<body>
<?php include "navbar.php"; ?>

<div class="score-box">
<h2>Your Trust Score</h2>
<div class="score"><?php echo $score; ?></div>
<div class="trust"><?php echo $trust; ?></div>

<div class="breakdown">
<p>📄 Total Reports: <b><?php echo $total; ?></b></p>
<p>✅ Completed Reports: <b><?php echo $completed; ?></b></p>
<p>❌ Fake Reports: <b><?php echo $fake; ?></b></p>
<p>⭐ Avg Feedback Rating: <b><?php echo round($avgRating,1); ?></b></p>
</div>
</div>

<?php include "footer.php"; ?>
</body>
</html>