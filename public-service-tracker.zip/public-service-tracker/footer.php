<div class="footer-profile">
    <footer class="footer">
        <div class="footer-container">
            <!-- Brand -->
            <div class="footer-brand">
                <h3>Service Tracker</h3>
                <p>
                    A public platform to report and track downtime of essential services
                    with transparency and accountability.
                </p>
            </div>

            <!-- Quick Links -->
            <div class="footer-links">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="user-dashboard.php">Dashboard</a></li>
                    <li><a href="report-downtime.php">Report Downtime</a></li>
                    <li><a href="my-reports.php">My Reports</a></li>
                </ul>
            </div>

            <!-- Support -->
            <div class="footer-links">
                <h4>Support</h4>
                <ul>
                    <li><a href="about.php">About</a></li>
                    <li><a href="about.php#privacy">Privacy Policy</a></li>
                    <li><a href="about.php#terms">Terms & Conditions</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
            </div>
        </div>

        <!-- Bottom -->
        <div class="footer-bottom">
            <p>
                © 2026 Public Service Downtime & Impact Tracker | Developer by :
                Shahzad Khan
            </p>
        </div>
    </footer>
</div>