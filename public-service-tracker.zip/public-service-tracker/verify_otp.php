<?php
include "db.php";

use PHPMailer\PHPMailer\PHPMailer;
require "PHPMailer/src/PHPMailer.php";
require "PHPMailer/src/SMTP.php";

$email = $_POST['email'];
$otp = $_POST['otp'];

/* Check OTP */
$q = $conn->query("SELECT * FROM otp_requests WHERE email='$email' AND otp='$otp'");

if($q->num_rows == 1){

    $data = $q->fetch_assoc();

    // Create user
    $conn->query("
      INSERT INTO users (full_name, email, mobile, city, address, otp_verified)
      VALUES (
        '{$data['name']}',
        '{$data['email']}',
        '{$data['mobile']}',
        '{$data['city']}',
        '{$data['address']}',
        1
      )
    ");

    // Delete OTP
    $conn->query("DELETE FROM otp_requests WHERE email='$email'");

    // Send welcome mail
    $mail = new PHPMailer();
    $mail->isSMTP();
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPAuth = true;
    $mail->Username = "khanshahzad90020@gmail.com";
    $mail->Password = "prgfgnfwsdybbede";
    $mail->SMTPSecure = "tls";
    $mail->Port = 587;

    $mail->setFrom("khanshahzad90020@gmail.com", "Service Tracker");
    $mail->addAddress($email);
    $mail->isHTML(true);
    $mail->Subject = "Welcome to Service Tracker";

    $mail->Body = "
    <h2>Welcome to Service Tracker</h2>
    <p>Dear {$data['name']},</p>
    <p>Your account has been successfully created.</p>
    <p>You can now login and start reporting public service issues.</p>
    <br>
    <b>Service Tracker Team</b>
    ";

    $mail->send();

    echo "verified";
}else{
    echo "wrong";
}
?>