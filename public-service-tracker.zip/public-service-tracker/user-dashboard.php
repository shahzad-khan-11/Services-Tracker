<?php
session_start();
include "db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}

$uid = $_SESSION['user_id'];

/* Count function */
function getCount($conn, $sql){
    $res = $conn->query($sql);
    if($res){
        $row = $res->fetch_assoc();
        return $row['c'];
    }
    return 0;
}

/* Stats */
$total      = getCount($conn, "SELECT COUNT(*) AS c FROM reports WHERE user_id=$uid");
$pending    = getCount($conn, "SELECT COUNT(*) AS c FROM reports WHERE user_id=$uid AND status='Pending'");
$resolved   = getCount($conn, "SELECT COUNT(*) AS c FROM reports WHERE user_id=$uid AND status='Completed'");
$inprogress = getCount($conn, "SELECT COUNT(*) AS c FROM reports WHERE user_id=$uid AND status='In Progress'");

/* Recent reports */
$recent = $conn->query("
    SELECT service_type, address, impact_level, status, created_at 
    FROM reports 
    WHERE user_id=$uid 
    ORDER BY created_at DESC 
    LIMIT 10
");
include "navbar.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>User Dashboard | Service Tracker</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/main.css">
</head>

<body>

    <!-- ================= DASHBOARD ================= -->
    <section class="dashboard">

        <h1>Dashboard Overview</h1>
        <p class="dashboard-sub">Track your reported issues and their current status.</p>

        <div class="stats-grid">
            <div class="stat-card total">
                <h3>Total Reports</h3>
                <span><?php echo $total; ?></span>
            </div>

            <div class="stat-card pending">
                <h3>Pending</h3>
                <span><?php echo $pending; ?></span>
            </div>

            <div class="stat-card inprogress">
                <h3>In Progress</h3>
                <span><?php echo $inprogress; ?></span>
            </div>

            <div class="stat-card resolved">
                <h3>Resolved</h3>
                <span><?php echo $resolved; ?></span>
            </div>
        </div>

        <div class="dashboard-section">
            <h2>Recent Reports</h2>

            <table class="reports-table">
                <thead>
                    <tr>
                        <th>Service</th>
                        <th>Location</th>
                        <th>Impact</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>

                    <?php if($recent && $recent->num_rows > 0){ 
while($r = $recent->fetch_assoc()){ ?>
                    <tr>
                        <td><?php echo $r['service_type']; ?></td>
                        <td><?php echo $r['address']; ?></td>
                        <td><?php echo $r['impact_level']; ?></td>
                        <td>
                            <span class="status <?php echo strtolower(str_replace(' ','',$r['status'])); ?>">
                                <?php echo $r['status']; ?>
                            </span>
                        </td>
                        <td><?php echo date("d M Y", strtotime($r['created_at'])); ?></td>
                    </tr>
                    <?php } } else { ?>
                    <tr>
                        <td colspan="5" style="text-align:center;">No reports found</td>
                    </tr>
                    <?php } ?>

                </tbody>
            </table>
        </div>
        <div class="print-dashboard">
            <button onclick="printDashboard()" class="print-btn">
                🖨️ Print
            </button>
        </div>
    </section>


    <!-- ================= FOOTER ================= -->
    <?php include "footer.php"; ?>

    <script>
    function printDashboard() {
        const nav = document.querySelector(".navbar");
        const footer = document.querySelector(".footer");

        nav.style.display = "none";
        footer.style.display = "none";

        window.print();

        nav.style.display = "flex";
        footer.style.display = "block";
    }
    </script>

</body>

</html>