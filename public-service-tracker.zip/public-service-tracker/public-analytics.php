<?php
session_start();
include "db.php";

/* ================= TOTAL REPORTS ================= */
$total = $conn->query("SELECT COUNT(*) AS c FROM reports")
              ->fetch_assoc()['c'];

/* ================= STATUS COUNTS ================= */
$pending = $conn->query("SELECT COUNT(*) AS c FROM reports WHERE status='Pending'")
                ->fetch_assoc()['c'];

$progress = $conn->query("SELECT COUNT(*) AS c FROM reports WHERE status='In Progress'")
                 ->fetch_assoc()['c'];

$completed = $conn->query("SELECT COUNT(*) AS c FROM reports WHERE status='Completed'")
                  ->fetch_assoc()['c'];

/* ================= SERVICE WISE ================= */
$serviceLabels = [];
$serviceValues = [];
$serviceQ = $conn->query("
    SELECT service_type, COUNT(*) AS c
    FROM reports
    GROUP BY service_type
");
while($r = $serviceQ->fetch_assoc()){
    $serviceLabels[] = $r['service_type'];
    $serviceValues[] = $r['c'];
}

/* ================= FEEDBACK RATINGS ================= */
$ratingLabels = [];
$ratingValues = [];

$ratingQ = $conn->query("SELECT rating, COUNT(*) AS c FROM feedback GROUP BY rating ORDER BY rating");

while($r = $ratingQ->fetch_assoc()){
    $ratingLabels[] = $r['rating']." Star";
    $ratingValues[] = $r['c'];
}


/* ================= CITY WISE ================= */
$cityLabels = [];
$cityValues = [];
$cityQ = $conn->query("
    SELECT city, COUNT(*) AS c
    FROM reports
    GROUP BY city
    ORDER BY c DESC
    LIMIT 8
");
while($r = $cityQ->fetch_assoc()){
    $cityLabels[] = $r['city'];
    $cityValues[] = $r['c'];
}

/* ================= DAILY REPORTS ================= */
$dayLabels = [];
$dayValues = [];
$dailyQ = $conn->query("
    SELECT DATE(created_at) AS d, COUNT(*) AS c
    FROM reports
    GROUP BY DATE(created_at)
    ORDER BY d DESC
    LIMIT 14
");
while($r = $dailyQ->fetch_assoc()){
    $dayLabels[] = $r['d'];
    $dayValues[] = $r['c'];
}
$dayLabels = array_reverse($dayLabels);
$dayValues = array_reverse($dayValues);
include "navbar.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Public Analytics | Service Tracker</title>
<link rel="stylesheet" href="css/main.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<!-- ANALYTICS -->
<section class="analytics-container">

<h1>India Public Service Downtime Analytics</h1>
<p class="analytics-sub">Live nationwide public service issue data.</p>

<div class="analytics-cards">
<div class="analytics-card"><h3>Total Reports</h3><span><?= $total ?></span></div>
<div class="analytics-card pending"><h3>Pending</h3><span><?= $pending ?></span></div>
<div class="analytics-card progress"><h3>In Progress</h3><span><?= $progress ?></span></div>
<div class="analytics-card resolved"><h3>Completed</h3><span><?= $completed ?></span></div>
</div>

<div class="analytics-charts">
<div class="analytics-charts">
<div class="chart-box">
    <h3>Status Distribution</h3>
    <canvas id="statusChart"></canvas>
</div>

<div class="chart-box">
    <h3>User Feedback Ratings</h3>
    <canvas id="ratingChart"></canvas>
</div>

<div class="chart-box">
    <h3>Service Wise Issues</h3>
    <canvas id="serviceChart"></canvas>
</div>

<div class="chart-box full"><canvas id="cityChart"></canvas></div>
<div class="chart-box full"><canvas id="dailyChart"></canvas></div>
</div>

</section>

   <footer class="footer">
      <div class="footer-container">
        <!-- Brand -->
        <div class="footer-brand">
          <h3>Service Tracker</h3>
          <p>
            A public platform to report and track downtime of essential services
            with transparency and accountability.
          </p>
        </div>

        <!-- Quick Links -->
        <div class="footer-links">
          <h4>Quick Links</h4>
          <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="user-dashboard.php">Dashboard</a></li>
            <li><a href="report-downtime.php">Report Downtime</a></li>
            <li><a href="my-reports.php">My Reports</a></li>
          </ul>
        </div>

        <!-- Support -->
        <div class="footer-links">
          <h4>Support</h4>
          <ul>
            <li><a href="about.php">About</a></li>
            <li><a href="about.php#privacy">Privacy Policy</a></li>
            <li><a href="about.php#terms">Terms & Conditions</a></li>
            <li><a href="contact.php">Contact</a></li>
          </ul>
        </div>
      </div>

      <!-- Bottom -->
      <div class="footer-bottom">
        <p>
          © 2026 Public Service Downtime & Impact Tracker | Developer by :
          Shahzad Khan
        </p>
      </div>
    </footer>


<script>
new Chart(document.getElementById("statusChart"),{
 type:"pie",
 data:{
  labels:["Pending","In Progress","Completed"],
  datasets:[{
   data:[<?= $pending ?>,<?= $progress ?>,<?= $completed ?>],
   backgroundColor:["#f59e0b","#3b82f6","#22c55e"]
  }]
 }
});

new Chart(document.getElementById("serviceChart"),{
 type:"bar",
 data:{
  labels: <?= json_encode($serviceLabels) ?>,
  datasets:[{
   label:"Issues",
   data: <?= json_encode($serviceValues) ?>,
   backgroundColor:"#2563eb"
  }]
 }
});

new Chart(document.getElementById("ratingChart"),{
 type:"doughnut",
 data:{
  labels: <?= json_encode($ratingLabels) ?>,
  datasets:[{
   data: <?= json_encode($ratingValues) ?>,
   backgroundColor:["#ef4444","#f97316","#facc15","#22c55e","#3b82f6"]
  }]
 }
});


new Chart(document.getElementById("cityChart"),{
 type:"bar",
 data:{
  labels: <?= json_encode($cityLabels) ?>,
  datasets:[{
   label:"Complaints",
   data: <?= json_encode($cityValues) ?>,
   backgroundColor:"#16a34a"
  }]
 },
 options:{ indexAxis:"y" }
});

new Chart(document.getElementById("dailyChart"),{
 type:"line",
 data:{
  labels: <?= json_encode($dayLabels) ?>,
  datasets:[{
   label:"Reports",
   data: <?= json_encode($dayValues) ?>,
   borderColor:"#2563eb",
   fill:false,
   tension:0.3
  }]
 }
});

</script>

</body>
</html>