<?php
session_start();
include "db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}

$uid = $_SESSION['user_id'];
$user = $conn->query("SELECT full_name,email,mobile,city,address FROM users WHERE id=$uid")->fetch_assoc();

$success = false;
if(isset($_SESSION['profile_success'])){
    $success = true;
    unset($_SESSION['profile_success']);
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>My Profile | Service Tracker</title>
    <link rel="stylesheet" href="css/main.css">

    <style>
    .profile-wrapper {
        max-width: 900px;
        margin: 70px auto;
        background: #fff;
        border-radius: 16px;
        box-shadow: 0 20px 50px rgba(0, 0, 0, .25);
        overflow: hidden;
    }

    .profile-top {
        background: linear-gradient(135deg, #1e3a8a, #2563eb);
        color: white;
        padding: 30px;
        display: flex;
        align-items: center;
        gap: 25px;
    }

    .profile-avatar {
        width: 90px;
        height: 90px;
        border-radius: 50%;
        background: #e0e7ff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 36px;
        font-weight: bold;
        color: #1e40af;
        position: relative;
    }

    .edit-avatar {
        position: absolute;
        bottom: -6px;
        right: -6px;
        background: #22c55e;
        color: #0f172a;
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        font-size: 16px;
    }

    .profile-name h2 {
        margin: 0;
    }

    .profile-name p {
        margin: 4px 0 0;
        opacity: .9;
        margin-left: 4px;
        font-size: 18px;
    }

    .profile-body {
        padding: 30px;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }

    .profile-group {
        display: flex;
        flex-direction: column;
    }

    .profile-group label {
        font-weight: 600;
        margin-bottom: 6px;
        color: #374151;
    }

    .profile-group input,
    .profile-group textarea {
        padding: 12px;
        border: 1px solid #d1d5db;
        border-radius: 10px;
        font-size: 15px;
        background: #f8fafc;
    }

    .profile-group textarea {
        resize: none;
        grid-column: span 2;
    }

    .profile-group input:read-only,
    .profile-group textarea:read-only {
        background: #f1f5f9;
        color: #64748b;
    }

    .profile-footer {
        padding: 20px 30px;
        background: #f9fafb;
        text-align: right;
    }

    .save-btn {
        background: linear-gradient(135deg, #2563eb, #1e40af);
        color: white;
        padding: 12px 40px;
        border: none;
        border-radius: 12px;
        font-size: 16px;
        cursor: pointer;
        display: none;
    }

    .save-btn.loading {
        background: #94a3b8;
        pointer-events: none;
    }

    .success-msg {
        margin: 15px 30px;
        color: #16a34a;
        font-weight: 600;
    }
    </style>
</head>

<body>

    <?php include "navbar.php"; ?>

    <div class="profile-wrapper">

        <div class="profile-top">
            <div class="profile-avatar">
                <?= strtoupper(substr($_SESSION['user_name'],0,1)) ?>
                <div class="edit-avatar" onclick="enableEdit()">✎</div>
            </div>

            <div class="profile-name">
                <h2>🧑<?= $_SESSION['user_name'] ?></h2>
                <p> 💌<?= $_SESSION['user_email'] ?></p>
            </div>
        </div>

        <?php if($success){ ?>
        <div class="success-msg">Profile updated successfully. A confirmation email has been sent.</div>
        <?php } ?>

        <form method="POST" action="update_profile.php" id="profileForm">

            <div class="profile-body">

                <div class="profile-group">
                    <label>Full Name</label>
                    <input type="text" name="name" value="<?= $user['full_name'] ?>" readonly required>
                </div>

                <div class="profile-group">
                    <label>Mobile</label>
                    <input type="text" name="mobile" value="<?= $user['mobile'] ?>" readonly required>
                </div>

                <div class="profile-group">
                    <label>City</label>
                    <input type="text" name="city" value="<?= $user['city'] ?>" readonly required>
                </div>

                <div class="profile-group">
                    <label>Address</label>
                    <textarea name="address" readonly required><?= $user['address'] ?></textarea>
                </div>

            </div>

            <div class="profile-footer">
                <button type="submit" id="saveBtn" class="save-btn">Update Profile</button>
            </div>

        </form>

    </div>

    <?php include "footer.php"; ?>

    <script>
    function enableEdit() {
        const fields = document.querySelectorAll("#profileForm input, #profileForm textarea");
        fields.forEach(f => f.removeAttribute("readonly"));
        document.getElementById("saveBtn").style.display = "inline-block";
    }

    document.getElementById("profileForm").addEventListener("submit", function() {
        const btn = document.getElementById("saveBtn");
        btn.classList.add("loading");
        btn.innerHTML = "Updating...";
    });
    </script>

</body>

</html>