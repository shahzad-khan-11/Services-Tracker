<?php
session_start();
include "db.php";

use PHPMailer\PHPMailer\PHPMailer;
require "PHPMailer/src/PHPMailer.php";
require "PHPMailer/src/SMTP.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$uid = $_SESSION['user_id'];

/* ---------------- Input Validation ---------------- */
$name    = trim($_POST['name'] ?? "");
$mobile  = trim($_POST['mobile'] ?? "");
$city    = trim($_POST['city'] ?? "");
$address = trim($_POST['address'] ?? "");

if ($name == "" || $mobile == "" || $city == "" || $address == "") {
    $_SESSION['profile_error'] = "All fields are required.";
    header("Location: profile.php");
    exit;
}

if (!preg_match("/^[0-9]{10}$/", $mobile)) {
    $_SESSION['profile_error'] = "Invalid mobile number.";
    header("Location: profile.php");
    exit;
}

/* ---------------- Update User ---------------- */
$stmt = $conn->prepare("
    UPDATE users 
    SET full_name = ?, mobile = ?, city = ?, address = ?
    WHERE id = ?
");
$stmt->bind_param("ssssi", $name, $mobile, $city, $address, $uid);

if (!$stmt->execute()) {
    $_SESSION['profile_error'] = "Failed to update profile.";
    header("Location: profile.php");
    exit;
}

/* Update session */
$_SESSION['user_name'] = $name;

/* ---------------- Send Email ---------------- */
$email = $_SESSION['user_email'];

$mail = new PHPMailer();
$mail->isSMTP();
$mail->Host = "smtp.gmail.com";
$mail->SMTPAuth = true;
$mail->Username = "khanshahzad90020@gmail.com";   // your email
$mail->Password = "prgfgnfwsdybbede";             // app password
$mail->SMTPSecure = "tls";
$mail->Port = 587;

$mail->setFrom("khanshahzad90020@gmail.com", "Service Tracker");
$mail->addAddress($email);
$mail->Subject = "Your Profile Was Updated";

$mail->Body = "
Hello $name,

Your Service Tracker profile has been successfully updated.

Updated details:
Name: $name
Mobile: $mobile
City: $city

If this was not you, please contact support immediately.

Thank you,
Service Tracker Team
";

/* Even if email fails, profile is already updated */
$mail->send();

/* Success flag */
$_SESSION['profile_success'] = true;

header("Location: profile.php");
exit;
?>