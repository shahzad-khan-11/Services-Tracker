<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}
include "navbar.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Report Downtime | Service Tracker</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/main.css">
</head>
<body>

<?php if(isset($_SESSION['report_success'])){ ?>
<div class="success-box">
<?php echo $_SESSION['report_success']; unset($_SESSION['report_success']); ?>
</div>
<?php } ?>

<?php if(isset($_SESSION['report_error'])){ ?>
<div class="error-box">
<?php echo $_SESSION['report_error']; unset($_SESSION['report_error']); ?>
</div>
<?php } ?>

<section class="report-container">
<h1>Report Public Service Downtime</h1>
<p class="report-sub">Submit the details of the issue you are facing.</p>

<form method="POST" action="submit_report.php" class="report-form" id="reportForm">

<div class="form-group">
<label>Service Type</label>
<select name="service_type" required>
<option value="">Select Service</option>
<option>Electricity</option>
<option>Water Supply</option>
<option>Internet</option>
<option>Public Transport</option>
</select>
</div>

<div class="form-group">
<label>Impact Level</label>
<select name="impact_level" required>
<option value="">Select Impact</option>
<option>Low</option>
<option>Medium</option>
<option>High</option>
</select>
</div>

<div class="form-group">
<label>PIN Code</label>
<input type="text" id="pincode" name="pincode" placeholder="Enter 6 digit PIN" maxlength="6" onkeyup="loadPinAreas()" required>
<small id="pinMsg" class="helper-text"></small>
</div>

<div class="form-group">
<label>Select Area</label>
<select id="areaSelect" onchange="selectArea()" disabled>
    <option>Select Area</option>
</select>
</div>

<div class="form-group">
<label>City</label>
<input type="text" name="city" id="city" readonly required>
</div>

<div class="form-group">
<label>Full Address</label>
<textarea name="address" id="address" rows="1" required></textarea>
</div>

<div class="form-group">
<label>Issue Description</label>
<textarea class = "issue-description" name="description" rows="4" placeholder="Describe the issue (optional)"></textarea>
</div>

<button type="submit" class="submit-report-btn" id="submitBtn">
<span id="btnText">Submit Downtime Report</span>
<span id="btnLoader" style="display:none;">⏳</span>
</button>

<small id="submitMsg" class="helper-text"></small>

</form>
</section>

<?php include "footer.php"; ?>

<script>
const pincode = document.getElementById("pincode");
const pinMsg = document.getElementById("pinMsg");
const areaSelect = document.getElementById("areaSelect");
const city = document.getElementById("city");
const address = document.getElementById("address");

let pinTimer = null;

function resetAddress(){
    areaSelect.innerHTML = "<option>Select Area</option>";
    areaSelect.disabled = true;
    city.value = "";
    address.value = "";
}

function loadPinAreas(){
    clearTimeout(pinTimer);
    const pin = pincode.value.trim();
    resetAddress();

    if(!/^[1-9][0-9]{5}$/.test(pin)){
        pinMsg.innerText = "Enter valid 6 digit PIN";
        return;
    }

    pinMsg.innerText = "Fetching areas...";

    pinTimer = setTimeout(()=>{
        fetch("https://api.postalpincode.in/pincode/"+pin)
        .then(r=>r.json())
        .then(d=>{
            if(d[0].Status !== "Success"){
                pinMsg.innerText = "PIN not found";
                return;
            }

            areaSelect.innerHTML = "<option value=''>Select Area</option>";

            d[0].PostOffice.forEach(p=>{
                const opt = document.createElement("option");
                opt.value = JSON.stringify(p);
                opt.text = p.Name + ", " + p.District + ", " + p.State;
                areaSelect.appendChild(opt);
            });

            areaSelect.disabled = false;
            pinMsg.innerText = "Select your area";
        })
        .catch(()=>{
            pinMsg.innerText = "Unable to fetch PIN data";
        });
    },500);
}

function selectArea(){
    if(!areaSelect.value) return;

    const p = JSON.parse(areaSelect.value);
    city.value = p.District;
    address.value = p.Name + ", " + p.Block + ", " + p.District + ", " + p.State;
    pinMsg.innerText = "Address filled successfully";
}

document.getElementById("reportForm").addEventListener("submit", function(){
    document.getElementById("submitBtn").disabled = true;
    document.getElementById("btnText").innerText = "Submitting...";
    document.getElementById("btnLoader").style.display = "inline-block";
});
</script>

</body>
</html>