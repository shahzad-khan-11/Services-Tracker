<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>About | Service Tracker</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/main.css">
</head>
<body>
<?php session_start(); 
include "navbar.php"; ?>


<!-- ================= ABOUT ================= -->
<section class="about-container">

<h1>About Service Tracker</h1>
<p class="about-sub">
Service Tracker is a public platform that allows citizens to report and track problems related to essential services like electricity, water supply, internet and public transport.
</p>

<div class="about-grid">

<div class="about-card">
<h3>Why this system exists</h3>
<p>
Many people face public service problems every day, but there is no single place where these issues are properly recorded and tracked.  
Service Tracker gives citizens a voice and helps authorities see where problems are happening and how serious they are.
</p>
</div>

<div class="about-card">
<h3>How citizens use it</h3>
<p>
Anyone can create an account and report a service problem in their area.  
Once a report is submitted, its status can be tracked until it is solved.
</p>
</div>

<div class="about-card">
<h3>How it helps the public</h3>
<p>
All reports contribute to a public dashboard that shows how many problems are pending, in progress, or completed across different cities.  
This brings transparency and accountability.
</p>
</div>

<div class="about-card">
<h3>Who benefits</h3>
<p>
Citizens get faster responses, and authorities get clear data to improve services.  
This creates a better, more responsive public service system.
</p>
</div>

</div>

</section>

<!-- ================= PRIVACY ================= -->
<section class="about-container" id="privacy">
<h1>Privacy Policy</h1>
<p>
We respect your privacy. Your personal information such as name, email and contact number is used only to identify your reports and communicate important updates.  
We do not sell, share or misuse your personal data.
</p>
</section>

<!-- ================= SAFETY ================= -->
<section class="about-container" id="safety">
<h1>Safety & Security</h1>
<p>
Your account is protected through secure verification. All reports are monitored to prevent misuse.  
We aim to keep this platform safe, reliable and trustworthy for all users.
</p>
</section>

<!-- ================= TERMS ================= -->
<section class="about-container" id="terms">
<h1>Terms & Conditions</h1>
<p>
By using Service Tracker, you agree to provide correct and honest information.  
Submitting false reports, abusive content or misleading data may lead to account suspension.
</p>
</section>
<!-- ================= FOOTER ================= -->
    <?php include "footer.php"; ?>

</body>
</html>