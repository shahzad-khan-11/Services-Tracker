<?php
session_start();
include "db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Feedback | Service Tracker</title>
    <link rel="stylesheet" href="css/main.css">
</head>

<body>
    <?php include "navbar.php"; ?>

    <!-- ================= FEEDBACK FORM ================= -->
    <section class="report-container">
        <h1>Share Your Feedback</h1>
        <p class="report-sub">Your feedback helps us improve public service reporting.</p>

        <form id="feedbackForm">

            <div class="form-rating">
                <label>Rate Our Service</label>
                <select name="rating" required>
                    <option value="">Select Rating</option>
                    <option value="5">Excellent</option>
                    <option value="4">Good</option>
                    <option value="3">Average</option>
                    <option value="2">Poor</option>
                    <option value="1">Very Bad</option>
                </select>
            </div>

            <div class="form-group">
                <label>Your Feedback</label>
                <textarea name="message" rows="4" required></textarea>
            </div>

            <button type="submit" id="submitBtn" class="submit-report-btn">
                Submit Feedback
            </button>

            <p id="feedbackMsg" class="helper-text"></p>

        </form>

    </section>

    <?php include "footer.php"; ?>

    <script>
 

    document.getElementById("feedbackForm").addEventListener("submit", function(e) {
        e.preventDefault();

        const form = this;
        const btn = document.getElementById("submitBtn");
        const msg = document.getElementById("feedbackMsg");

        btn.innerHTML = "Submitting...";
        btn.disabled = true;
        msg.innerText = "";

        const data = new FormData(form);

        fetch("submit_feedback.php", {
                method: "POST",
                body: data
            })
            .then(res => res.text())
            .then(res => {
                if (res.trim() === "success") {
                    msg.style.color = "green";
                    msg.innerText = "Your feedback has been submitted successfully.";
                    form.reset();
                } else {
                    msg.style.color = "red";
                    msg.innerText = res;
                }
            })
            .finally(() => {
                btn.innerHTML = "Submit Feedback";
                btn.disabled = false;
            });
    });
    </script>

</body>

</html>