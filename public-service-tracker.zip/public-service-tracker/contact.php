<?php session_start(); 
include "navbar.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Contact Us | Service Tracker</title>
    <link rel="stylesheet" href="css/main.css">
</head>

<body>


    <section class="signup-container">
        <h1>Contact Us</h1>
        <p>Have a question or issue? Send us a message.</p>

        <form method="POST" action="send_contact.php">

            <div class="form-group">
                <label>Your Name</label>
                <input type="text" name="name" required>
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" required>
            </div>

            <div class="form-group">
                <label>Subject</label>
                <input type="text" name="subject" required>
            </div>

            <div class="form-group">
                <label>Message</label>
                <textarea name="message" rows="4" required></textarea>
            </div>

            <button type="submit">Send Message</button>

            <?php if(isset($_GET['sent'])){ ?>
            <small class="helper-text">Message sent successfully. We will contact you soon.</small>
            <?php } ?>

        </form>
    </section>

    <?php include "footer.php"; ?>

</body>

</html>