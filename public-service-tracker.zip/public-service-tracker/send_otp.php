<?php
include "db.php";

use PHPMailer\PHPMailer\PHPMailer;
require "PHPMailer/src/PHPMailer.php";
require "PHPMailer/src/SMTP.php";

/* ==== Basic validation ==== */
if (
    empty($_POST['name']) ||
    empty($_POST['email']) ||
    empty($_POST['mobile']) ||
    empty($_POST['city']) ||
    empty($_POST['address'])
) {
    echo "Please fill all required fields";
    exit;
}

$name    = $conn->real_escape_string($_POST['name']);
$email   = $conn->real_escape_string($_POST['email']);
$mobile  = $conn->real_escape_string($_POST['mobile']);
$city    = $conn->real_escape_string($_POST['city']);
$address = $conn->real_escape_string($_POST['address']);

/* ==== Already registered check ==== */
$checkUser = $conn->query("SELECT id FROM users WHERE email='$email'");
if ($checkUser && $checkUser->num_rows > 0) {
    echo "Email already registered";
    exit;
}

/* ==== Generate OTP ==== */
$otp = rand(100000, 999999);

/* ==== Remove old OTP (Resend case) ==== */
$conn->query("DELETE FROM otp_requests WHERE email='$email'");

/* ==== Store temp signup data + OTP ==== */
$insertReq = $conn->query("
    INSERT INTO otp_requests (email, name, mobile, city, address, otp)
    VALUES ('$email', '$name', '$mobile', '$city', '$address', '$otp')
");

if (!$insertReq) {
    echo "OTP request database error";
    exit;
}

/* ==== Log OTP ==== */
$conn->query("
    INSERT INTO otp_logs (email, otp)
    VALUES ('$email', '$otp')
");

/* ==== Send OTP Email ==== */
$mail = new PHPMailer(true);
$mail->isSMTP();
$mail->Host       = "smtp.gmail.com";
$mail->SMTPAuth   = true;
$mail->Username   = "khanshahzad90020@gmail.com";   // your gmail
$mail->Password   = "prgfgnfwsdybbede";             // app password
$mail->SMTPSecure = "tls";
$mail->Port       = 587;

$mail->setFrom("khanshahzad90020@gmail.com", "Service Tracker");
$mail->addAddress($email);
$mail->Subject = "OTP Verification - Service Tracker";
$mail->Body    = "Your OTP is: $otp";

if ($mail->send()) {
    echo "sent";
} else {
    echo "Email send failed";
}
?>
