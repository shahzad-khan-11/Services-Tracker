<?php
session_start();
include "db.php";

$result = null;
$error = "";

if(isset($_POST['complaint_id'])){
    $no = trim($_POST['complaint_id']);

    if($no != ""){
        $stmt = $conn->prepare("SELECT service_type, city, impact_level, status, created_at FROM reports WHERE complaint_id=?");
        $stmt->bind_param("s",$no);
        $stmt->execute();
        $res = $stmt->get_result();

        if($res->num_rows > 0){
            $result = $res->fetch_assoc();
        } else {
            $error = "Invalid Complaint Number";
        }
    }
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Track Complaint | Service Tracker</title>
    <link rel="stylesheet" href="css/main.css">
</head>

<body>
<?php include "navbar.php"; ?>
    <div class="track-container">
        <h1>Track Your Complaint</h1>
        <p>Enter your complaint number received on email.</p>

        <form method="POST" class="track-form">
            <input type="text" name="complaint_id" placeholder="Eg: ST-2026-BH-1234" required>
            <button type="submit">Track Complaint</button>
        </form>

        <?php if($result){ ?>
        <div class="track-result">
            <h3>Status: <span class="status <?= strtolower(str_replace(' ','',$result['status'])) ?>">
                    <?= $result['status'] ?></span></h3>

            <p><b>Service:</b> <?= $result['service_type'] ?></p>
            <p><b>City:</b> <?= $result['city'] ?></p>
            <p><b>Impact Level:</b> <?= $result['impact_level'] ?></p>
            <p><b>Reported On:</b> <?= date("d M Y, h:i A",strtotime($result['created_at'])) ?></p>
        </div>
        <?php } ?>

        <?php if($error!=""){ ?>
        <p class="error-text"><?= $error ?></p>
        <?php } ?>

    </div>

    <div class="footer-profile">
        <?php include "footer.php"; ?>
    </div>
</body>

</html>