<?php
include "db.php";

use PHPMailer\PHPMailer\PHPMailer;
require "PHPMailer/src/PHPMailer.php";
require "PHPMailer/src/SMTP.php";

if(!isset($_POST['email'])){
    echo "Email required";
    exit;
}

$email = trim($_POST['email']);

if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
    echo "Invalid email";
    exit;
}

/* Check user exists */
$check = $conn->prepare("SELECT id FROM users WHERE email=?");
$check->bind_param("s", $email);
$check->execute();
$res = $check->get_result();

if($res->num_rows == 0){
    echo "Email not registered";
    exit;
}

/* Generate OTP */
$otp = rand(100000,999999);

/* Replace old OTP */
$conn->query("DELETE FROM otp_requests WHERE email='$email'");
$conn->query("INSERT INTO otp_requests(email,otp) VALUES('$email','$otp')");
$conn->query("INSERT INTO otp_logs(email,otp) VALUES('$email','$otp')");

/* Send Mail */
$mail = new PHPMailer(true);
$mail->isSMTP();
$mail->Host = "smtp.gmail.com";
$mail->SMTPAuth = true;
$mail->Username = "khanshahzad90020@gmail.com";
$mail->Password = "prgfgnfwsdybbede";
$mail->SMTPSecure = "tls";
$mail->Port = 587;

$mail->setFrom("khanshahzad90020@gmail.com","Service Tracker");
$mail->addAddress($email);
$mail->Subject = "Your Login OTP";
$mail->Body = "Your login OTP is: $otp";

try{
    $mail->send();
    echo "sent";
}catch(Exception $e){
    echo "Mail error";
}
?>
