<?php
session_start();
include "db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}

$uid = $_SESSION['user_id'];

/* ---------------- Filters ---------------- */
$serviceFilter = $_GET['service'] ?? '';
$statusFilter  = $_GET['status'] ?? '';

$where = "WHERE user_id = $uid AND user_hidden = 0";

if($serviceFilter != ''){
    $sf = $conn->real_escape_string($serviceFilter);
    $where .= " AND service_type = '$sf'";
}

if($statusFilter != ''){
    $st = $conn->real_escape_string($statusFilter);
    $where .= " AND status = '$st'";
}

/* ---------------- Fetch Reports ---------------- */
$reports = $conn->query("
    SELECT id, service_type, address, impact_level, status, created_at
    FROM reports
    $where
    ORDER BY created_at DESC
");
include "navbar.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Reports | Service Tracker</title>
<link rel="stylesheet" href="css/main.css">
</head>
<body>

<!-- ================= MY REPORTS ================= -->
<section class="myreports-container">
<h1>My Reported Issues</h1>
<p class="myreports-sub">View and manage all your submitted reports.</p>

<!-- ================= FILTER ================= -->
<form method="GET" class="filter-bar">
<select name="service" class="finding">
<option value="">All Services</option>
<option value="Electricity" <?=($serviceFilter=="Electricity")?"selected":""?>>Electricity</option>
<option value="Water Supply" <?=($serviceFilter=="Water Supply")?"selected":""?>>Water Supply</option>
<option value="Internet" <?=($serviceFilter=="Internet")?"selected":""?>>Internet</option>
<option value="Public Transport" <?=($serviceFilter=="Public Transport")?"selected":""?>>Public Transport</option>
</select>

<select name="status" class="finding">
<option value="">All Status</option>
<option value="Pending" <?=($statusFilter=="Pending")?"selected":""?>>Pending</option>
<option value="In Progress" <?=($statusFilter=="In Progress")?"selected":""?>>In Progress</option>
<option value="Completed" <?=($statusFilter=="Completed")?"selected":""?>>Completed</option>
</select>

<button type="submit" class="finding-btn">Filter</button>
</form>

<!-- ================= TABLE ================= -->
<div class="table-box">
<table class="reports-table">
<thead>
<tr>
<th>Service</th>
<th>Location</th>
<th>Impact</th>
<th>Status</th>
<th>Date</th>
<th>Action</th>
</tr>
</thead>
<tbody>

<?php if($reports && $reports->num_rows > 0){ 
while($r = $reports->fetch_assoc()){
    $statusText = $r['status'];
    $statusClass = strtolower(str_replace(" ","",$statusText)); // pending, inprogress, completed
?>
<tr>
<td><?= htmlspecialchars($r['service_type']) ?></td>
<td><?= htmlspecialchars($r['address']) ?></td>
<td><?= htmlspecialchars($r['impact_level']) ?></td>
<td><span class="status <?= $statusClass ?>"><?= $statusText ?></span></td>
<td><?= date("d M Y", strtotime($r['created_at'])) ?></td>

<td>
<?php if($statusText === "Completed"){ ?>
<form method="POST" action="delete_report.php" onsubmit="return confirm('Remove this completed report from your view?');">
    <input type="hidden" name="id" value="<?= $r['id'] ?>">
    <button type="submit" class="delete-btn">Remove</button>
</form>
<?php } else { ?>
-
<?php } ?>
</td>
</tr>
<?php } } else { ?>
<tr><td colspan="6" style="text-align:center;">No reports found</td></tr>
<?php } ?>

</tbody>
</table>
</div>
</section>

<?php include "footer.php"; ?>
</body>
</html>