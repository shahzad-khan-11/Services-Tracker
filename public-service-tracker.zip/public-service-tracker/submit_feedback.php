<?php
session_start();
include "db.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require __DIR__ . "/PHPMailer/src/Exception.php";
require __DIR__ . "/PHPMailer/src/PHPMailer.php";
require __DIR__ . "/PHPMailer/src/SMTP.php";

/* ---------- Login check ---------- */
if (!isset($_SESSION['user_id'])) {
    echo "Not logged in";
    exit;
}

/* ---------- Logged in user ---------- */
$uid   = $_SESSION['user_id'];
$name  = $_SESSION['user_name'];   // for email only
$email = $_SESSION['user_email'];  // for email only

/* ---------- Form data ---------- */
$rating  = $_POST['rating'] ?? '';
$message = $_POST['message'] ?? '';

if ($rating === "" || $message === "") {
    echo "All fields required";
    exit;
}

/* ---------- Save feedback (ONLY user_id) ---------- */
$stmt = $conn->prepare(
    "INSERT INTO feedback (user_id, message, rating) VALUES (?,?,?)"
);
$stmt->bind_param("isi", $uid, $message, $rating);

if (!$stmt->execute()) {
    echo "Database error";
    exit;
}

/* ---------- Send confirmation email ---------- */
try {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = "smtp.gmail.com";
    $mail->SMTPAuth   = true;
    $mail->Username   = "khanshahzad90020@gmail.com";
    $mail->Password   = "prgfgnfwsdybbede";   // Gmail app password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    $mail->setFrom("khanshahzad90020@gmail.com", "Service Tracker");
    $mail->addAddress($email, $name);

    $mail->Subject = "Thank you for your feedback | Service Tracker";

    $mail->Body = "Hello $name,

Thank you for sharing your feedback with Service Tracker.

We have successfully received your response.

Your Rating: $rating / 5
Your Message:
$message

Your feedback helps us improve the public service reporting system.

Warm regards,
Service Tracker Team";

    $mail->send();
} catch (Exception $e) {
    // ignore mail error so feedback still works
}

echo "success";
exit;
