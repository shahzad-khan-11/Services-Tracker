<?php
include "db.php";
session_start();

if(!isset($_POST['email']) || !isset($_POST['otp'])){
    echo "Invalid";
    exit;
}

$email = trim($_POST['email']);
$otp = trim($_POST['otp']);

$q = $conn->prepare("SELECT * FROM otp_requests WHERE email=? AND otp=?");
$q->bind_param("ss", $email, $otp);
$q->execute();
$r = $q->get_result();

if($r->num_rows == 1){

    /* OTP correct → Login */
    $user = $conn->query("SELECT * FROM users WHERE email='$email'")->fetch_assoc();

$_SESSION['user_id'] = $user['id'];
$_SESSION['user_name'] = $user['full_name'];
$_SESSION['user_email'] = $user['email'];
$_SESSION['user_mobile'] = $user['mobile'];
    /* Remove OTP */
    $conn->query("DELETE FROM otp_requests WHERE email='$email'");

    echo "success";
}else{
    echo "Invalid OTP";
}
?>
