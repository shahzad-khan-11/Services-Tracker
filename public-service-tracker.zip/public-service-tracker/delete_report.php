<?php
session_start();
include "db.php";

/* User must be logged in */
if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}

/* Validate input */
if(!isset($_POST['id']) || !is_numeric($_POST['id'])){
    header("Location: my-reports.php");
    exit;
}

$report_id = (int) $_POST['id'];
$user_id   = $_SESSION['user_id'];


$stmt = $conn->prepare("UPDATE reports SET user_hidden = 1 WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $report_id, $user_id);
$stmt->execute();
$stmt->close();

/* Go back to My Reports */
header("Location: my-reports.php");
exit;
?>