<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Public Service Downtime & Impact Tracker</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Main CSS -->
    <link rel="stylesheet" href="css/main.css" />
  </head>
  <body>
    <?php session_start(); 
 include "navbar.php"; ?>

    <!-- ================= HERO SECTION ================= -->
    <section class="hero-bg">
      <div class="hero-overlay"></div>
      <div class="smart"><h1>SMART CITY</h1></div>
      

      <div class="hero-content">
        <h1>Public Service Downtime & Impact Tracker</h1>
        <p>
          Report, track, and analyze downtime of essential public services like
          electricity, water supply, internet connectivity, and transport to
          improve transparency and response time.
        </p>

       <div class="hero-actions">
<?php if(isset($_SESSION['user_id'])){ ?>
    <a href="report-downtime.php" class="primary-btn">Report Issue</a>
    <a href="user-dashboard.php" class="secondary-btn">View Dashboard</a>
<?php } else { ?>
    <a href="signup.php" class="primary-btn">Get Started</a>
    <a href="login.php" class="secondary-btn">Login</a>
<?php } ?>
</div>

<div class="btn-data">
    <a href="public-analytics.php">View Analytics</a>
</div>

      </div>
    </section>

    <!-- ================= FEATURES SECTION ================= -->
    <section class="features">
      <h2>Key Features</h2>

      <div class="feature-list">
        <div class="feature-item">
          <h3>Email OTP Authentication</h3>
          <p>Secure login and signup using email-based OTP verification.</p>
        </div>

        <div class="feature-item">
          <h3>Professional User Signup</h3>
          <p>Complete user profile creation with verified identity.</p>
        </div>

        <div class="feature-item">
          <h3>Live Location via Map</h3>
          <p>Automatic location and address detection using map services.</p>
        </div>

        <div class="feature-item">
          <h3>Downtime Reporting</h3>
          <p>Report service issues with impact level and description.</p>
        </div>

        <div class="feature-item">
          <h3>User Dashboard</h3>
          <p>Track submitted reports and their resolution status.</p>
        </div>

        <div class="feature-item">
          <h3>Email Notifications</h3>
          <p>Receive updates when issues are reviewed or resolved.</p>
        </div>
      </div>
    </section>

    <!-- ================= HOW IT WORKS ================= -->
    <section class="workflow">
      <h2>How It Works</h2>

      <ol>
        <li>User signs up with full details and verifies email using OTP.</li>
        <li>User logs in and accesses the dashboard.</li>
        <li>User reports downtime with live location and service details.</li>
        <li>Authorities review, update, and resolve reported issues.</li>
      </ol>
    </section>

    <?php include "footer.php"; ?>
  </body>
</html>
