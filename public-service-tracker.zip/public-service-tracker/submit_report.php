<?php
session_start();
include "db.php";

use PHPMailer\PHPMailer\PHPMailer;
require "PHPMailer/src/PHPMailer.php";
require "PHPMailer/src/SMTP.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit;
}

$user_id     = $_SESSION['user_id'];
$user_name   = $_SESSION['user_name'];
$user_email  = $_SESSION['user_email'];
$user_mobile = $_SESSION['user_mobile'] ?? '';

$service     = $_POST['service_type'] ?? '';
$impact      = $_POST['impact_level'] ?? '';
$address     = $_POST['address'] ?? '';
$city        = $_POST['city'] ?? '';
$pincode     = $_POST['pincode'] ?? '';
$description = $_POST['description'] ?? '';

if($service=="" || $impact=="" || $address=="" || $city==""){
    $_SESSION['report_error'] = "All required fields must be filled.";
    header("Location: report-downtime.php");
    exit;
}

/* ================= DAILY LIMIT CHECK ================= */

$limitCheck = $conn->prepare("
    SELECT COUNT(*) AS c 
    FROM reports 
    WHERE user_id = ? AND DATE(created_at) = CURDATE()
");
$limitCheck->bind_param("i", $user_id);
$limitCheck->execute();
$limitRow = $limitCheck->get_result()->fetch_assoc();

if($limitRow['c'] >= 4){
    $_SESSION['report_error'] = "You have reached today's limit of 4 reports. Please try again tomorrow.";
    header("Location: report-downtime.php");
    exit;
}

/* ================= GENERATE COMPLAINT NUMBER ================= */

/* City code */
$cityClean = strtoupper(preg_replace('/[^A-Za-z]/', '', $city));
$cityCode = substr($cityClean, 0, 2);
if(strlen($cityCode) < 2){
    $cityCode = "IN";
}

/* Next number */
$res = $conn->query("SELECT COUNT(*) AS c FROM reports");
$row = $res->fetch_assoc();
$next = $row['c'] + 1;

$year = date("Y");
$complaint_id = "ST-$year-$cityCode-".str_pad($next, 5, "0", STR_PAD_LEFT);

/* ================= INSERT REPORT ================= */

$stmt = $conn->prepare("
INSERT INTO reports 
(complaint_id, user_id, user_name, user_email, user_mobile, service_type, impact_level, address, city, pincode, description, status)
VALUES (?,?,?,?,?,?,?,?,?,?,?, 'Pending')
");

$stmt->bind_param(
    "sisssssssss",
    $complaint_id,
    $user_id,
    $user_name,
    $user_email,
    $user_mobile,
    $service,
    $impact,
    $address,
    $city,
    $pincode,
    $description
);

$stmt->execute();

/* ================= SEND EMAIL ================= */

$mail = new PHPMailer();
$mail->isSMTP();
$mail->Host = "smtp.gmail.com";
$mail->SMTPAuth = true;
$mail->Username = "khanshahzad90020@gmail.com";
$mail->Password = "prgfgnfwsdybbede";
$mail->SMTPSecure = "tls";
$mail->Port = 587;

$mail->setFrom("khanshahzad90020@gmail.com","Service Tracker");
$mail->addAddress($user_email);

$mail->Subject = "Your Complaint Registered – $complaint_id";

$mail->Body = "
Hello $user_name,

Your service complaint has been successfully registered.

Complaint Number: $complaint_id
Service: $service
Impact Level: $impact
City: $city
Status: Pending

Please keep this Complaint Number for tracking.

You will receive updates when the status changes.

Thank you for helping improve public services.

– Service Tracker
";

$mail->send();

/* ================= SUCCESS ================= */

$_SESSION['report_success'] = "Your report has been submitted successfully. Complaint No: $complaint_id";
header("Location: report-downtime.php");
exit;
?>