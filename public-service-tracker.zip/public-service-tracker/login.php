<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login | Service Tracker</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/main.css">
</head>

<body>
<?php session_start();
include "navbar.php"; ?>

<!-- ================= NAVBAR ================= -->

<!-- ================= LOGIN ================= -->
<section class="login-container">

<h1>Login</h1>
<p>Enter your registered email to receive OTP</p>

<form id="loginForm" novalidate>

<div class="form-group">
<label>Email Address</label>
<input type="email" id="loginEmail" placeholder="Enter your email">
<small class="error-text" id="email-error"></small>
</div>

<button type="button" id="sendLoginOtpBtn" onclick="sendLoginOtp()">Send OTP</button>

<div id="loginOtpBox" style="display:none; margin-top:20px;">
<div class="form-group">
<label>Enter OTP</label>
<input type="text" id="loginOtp" placeholder="6 digit OTP" maxlength="6" required>
</div>

<button type="button" onclick="verifyLoginOtp()">Verify & Login</button>
</div>

</form>

<p style="text-align:center;margin-top:15px;">
Don’t have an account? <a href="signup.php">Create one</a>
</p>

</section>

<!-- ================= FOOTER ================= -->
<?php include "footer.php"; ?>

<script>
let timer;
let seconds = 60;

function isValidEmail(email){
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function sendLoginOtp(){
 const email = document.getElementById("loginEmail").value.trim();
 const err = document.getElementById("email-error");
 const btn = document.getElementById("sendLoginOtpBtn");

 err.innerText="";
 err.style.color="red";

 if(email===""){
   err.innerText="Email required";
   return;
 }
 if(!isValidEmail(email)){
   err.innerText="Enter valid email";
   return;
 }

 btn.innerText="Sending...";
 btn.disabled=true;

 let fd=new FormData();
 fd.append("email",email);

 fetch("login_send_otp.php",{method:"POST",body:fd})
 .then(r=>r.text())
 .then(data=>{
   if(data==="sent"){
     document.getElementById("loginOtpBox").style.display="block";
     err.innerText="OTP sent to your email";
     err.style.color="green";
     startTimer();
   } else {
     btn.innerText="Send OTP";
     btn.disabled=false;
     err.innerText=data;
   }
 });
}

function startTimer(){
 const btn=document.getElementById("sendLoginOtpBtn");
 seconds=60;

 timer=setInterval(()=>{
  seconds--;
  btn.innerText="Resend in "+seconds+"s";

  if(seconds<=0){
    clearInterval(timer);
    btn.innerText="Resend OTP";
    btn.disabled=false;
  }
 },1000);
}

function verifyLoginOtp(){
 const email=document.getElementById("loginEmail").value;
 const otp=document.getElementById("loginOtp").value;

 let fd=new FormData();
 fd.append("email",email);
 fd.append("otp",otp);

 fetch("login_verify_otp.php",{method:"POST",body:fd})
 .then(r=>r.text())
 .then(data=>{
   if(data==="success"){
     window.location="user-dashboard.php";
   } else {
     alert("Invalid OTP");
   }
 });
}
</script>


</body>
</html>
