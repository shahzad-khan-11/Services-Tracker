<?php
$conn = new mysqli("localhost", "root", "Shahzad#@123", "service_tracker");

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
