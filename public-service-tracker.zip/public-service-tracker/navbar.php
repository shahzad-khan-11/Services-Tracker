<header class="navbar">
    <div class="nav-left">
        <div class="brand">
            <div class="brand-icon">
                <a href="index.php">
                    <img src="assets/Logo.png" alt="Service Tracker Logo" />
                </a>
            </div>

            <div class="brand-text">
                <a href="index.php">
                    <h2>Service Tracker</h2>
                    <p>Public Service Downtime Monitor</p>
                </a>
            </div>
        </div>
    </div>

    <div class="nav-center" id="mobileMenu">
        <nav>
            <a href="index.php">Home</a>
            <a href="public-analytics.php">Analytics</a>
            <a href="track-complaint.php">Track Complaint</a>
            <a href="about.php">About</a>

            <?php if(isset($_SESSION['user_id'])){ ?>
            <a href="report-downtime.php">Report Downtime</a>
            <a href="user-dashboard.php">Dashboard</a>
            <a href="feedback.php">Feedback</a>
            <?php } ?>
        </nav>
    </div>

    <div class="nav-right">
        <?php if(isset($_SESSION['user_id'])){ ?>
        <div class="user-menu">
            <div class="user-name" id="userMenuBtn" onclick="toggleUserMenu()">
                <?= $_SESSION['user_name'] ?>
                <span class="arrow">▾</span>
            </div>

            <div class="user-dropdown" id="userDropdown">
                <a href="my-reports.php">My Reports</a>
                <a href="profile.php">My Profile</a>
                <a href="score.php">My Score</a>
                <div class="dropdown-divider"></div>
                <a href="logout.php" class="logout">Logout</a>
            </div>
        </div>
        <?php } else { ?>
        <a href="login.php">Login</a>
        <a href="signup.php" class="btn-nav">Signup</a>
        <?php } ?>
    </div>

    <div class="hamburger" onclick="toggleMenu()">
        <span></span>
        <span></span>
        <span></span>
    </div>
</header>

<script>
const links = document.querySelectorAll(".nav-center nav a");
const currentPage = window.location.pathname.split("/").pop();
links.forEach((link) => {
    if (link.getAttribute("href") === currentPage) {
        link.classList.add("active");
    }
});

function toggleMenu() {
    const menu = document.getElementById("mobileMenu");
    if (menu.style.display === "flex") {
        menu.style.display = "none";
    } else {
        menu.style.display = "flex";
    }
}

function toggleUserMenu() {
    document.getElementById("userDropdown").classList.toggle("show");
}
document.addEventListener("click", function(e) {
    const menu = document.getElementById("userDropdown");
    const btn = document.getElementById("userMenuBtn");
    if (!menu || !btn) return;
    if (!menu.contains(e.target) && !btn.contains(e.target)) {
        menu.classList.remove("show");
    }
});
</script>