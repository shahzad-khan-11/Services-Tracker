<?php
include "db.php";

use PHPMailer\PHPMailer\PHPMailer;
require "PHPMailer/src/PHPMailer.php";
require "PHPMailer/src/SMTP.php";

$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

/* Save in DB */
$conn->query("INSERT INTO contact_messages(name,email,subject,message)
VALUES('$name','$email','$subject','$message')");

/* Send mail to admin */
$mail = new PHPMailer();
$mail->isSMTP();
$mail->Host="smtp.gmail.com";
$mail->SMTPAuth=true;
$mail->Username="khanshahzad90020@gmail.com";
$mail->Password="prgfgnfwsdybbede";
$mail->SMTPSecure="tls";
$mail->Port=587;

$mail->setFrom($email,$name);
$mail->addAddress("khanshahzad90020@gmail.com");

$mail->Subject="Contact Form: $subject";
$mail->Body="
Name: $name
Email: $email

Message:
$message
";

$mail->send();

header("Location: contact.php?sent=1");
exit;
?>
