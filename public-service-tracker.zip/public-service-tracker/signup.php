<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Signup | Service Tracker</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/main.css">
</head>

<body>

<?php session_start(); include "navbar.php"; ?>

<section class="signup-container">
<h1>Create Account</h1>
<p>Email OTP verification required</p>

<form id="signupForm">

<div class="form-group">
<label>Full Name</label>
<input type="text" name="name" required>
</div>

<div class="form-group">
<label>Email</label>
<input type="email" name="email" id="email" required>
</div>

<div class="form-group">
<label>Mobile</label>
<input type="text" name="mobile" required maxlength="10">
</div>

<div class="form-group">
<label>PIN Code</label>
<input type="text" id="pincode" name="pincode" maxlength="6" placeholder="Enter 6 digit PIN" onkeyup="loadPinAreas()" required>
<small id="pinMsg" class="helper-text"></small>
</div>

<div class="form-group">
<label>Select Area</label>
<select style = "width:100%; padding: 10px; border-radius: 5px;" id="areaSelect" disabled onchange="selectArea()">
<option>Select Area</option>
</select>
</div>

<div class="form-group">
<label>City</label>
<input type="text" name="city" id="city" readonly required>
</div>

<div class="form-group">
<label>Address</label>
<textarea name="address" id="address" required></textarea>
</div>

<button type="button" id="sendOtpBtn" onclick="sendOtp()">Send OTP</button>
<p id="otpMsg"></p>

<div id="otpBox" class="otp-box" style="display:none;">
<div class="form-group">
<label>Enter OTP</label>
<input type="text" id="otp" maxlength="6">
</div>
<button type="button" onclick="verifyOtp()">Verify OTP & Create Account</button>
</div>

</form>
</section>

<?php include "footer.php"; ?>

<script>
let pinTimer=null;

function loadPinAreas(){
    clearTimeout(pinTimer);
    const pin=pincode.value.trim();
    const pinMsg=document.getElementById("pinMsg");
    const area=document.getElementById("areaSelect");

    area.innerHTML="<option>Select Area</option>";
    area.disabled=true;

    if(!/^[1-9][0-9]{5}$/.test(pin)){
        pinMsg.innerText="Enter valid 6 digit PIN";
        return;
    }

    pinMsg.innerText="Fetching areas...";

    pinTimer=setTimeout(()=>{
        fetch("https://api.postalpincode.in/pincode/"+pin)
        .then(r=>r.json())
        .then(d=>{
            if(d[0].Status!=="Success"){
                pinMsg.innerText="PIN not found";
                return;
            }

            d[0].PostOffice.forEach(p=>{
                let o=document.createElement("option");
                o.value=JSON.stringify(p);
                o.text=p.Name+", "+p.District+", "+p.State;
                area.appendChild(o);
            });

            area.disabled=false;
            pinMsg.innerText="Select your area";
        });
    },500);
}

function selectArea(){
    const p=JSON.parse(areaSelect.value);
    city.value=p.District;
    address.value=p.Name+", "+p.Block+", "+p.District+", "+p.State;
    pinMsg.innerText="Address filled";
}

/* ================= OTP ================= */

function sendOtp(){
    const f=document.getElementById("signupForm");
    const btn=document.getElementById("sendOtpBtn");
    const msg=document.getElementById("otpMsg");

    btn.disabled=true;
    btn.innerText="Sending...";

    fetch("send_otp.php",{method:"POST",body:new FormData(f)})
    .then(r=>r.text())
    .then(res=>{
        if(res=="sent"){
            otpBox.style.display="block";
            msg.innerText="OTP sent to your email";
            msg.style.color="green";
        }else{
            btn.disabled=false;
            btn.innerText="Send OTP";
            msg.innerText=res;
            msg.style.color="red";
        }
    });
}

function verifyOtp(){
    let fd=new FormData();
    fd.append("email",email.value);
    fd.append("otp",otp.value);

    fetch("verify_otp.php",{method:"POST",body:fd})
    .then(r=>r.text())
    .then(res=>{
        if(res=="verified"){
            otpMsg.innerText="Account created. Redirecting...";
            setTimeout(()=>window.location="login.php",2000);
        }else otpMsg.innerText="Invalid OTP";
    });
}
</script>

</body>
</html>